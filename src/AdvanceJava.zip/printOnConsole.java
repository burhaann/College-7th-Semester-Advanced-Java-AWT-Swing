package com.AdvanceJava;

public class printOnConsole {

  public static void main(String[] args) {
  
  System.out.println("Welcome to Java");
  System.out.println("Learning Java Now");
  System.out.println("Programming is Fun");

  }

}
